aim_config = {
    tracking = {
        radius = 999,
        fov = 360,
        smoothing = 0.01,
        prediction_strength = 999.0,
        target_lock = true,
        through_walls = true
    },
    
    assistance = {
        magnetic_strength = 999.0,
        sticky_aim = true,
        auto_track = true,
        head_priority = true,
        instant_lock = true
    },
    
    advanced = {
        prediction_time = 1.0,
        recoil_control = 0.0,
        spread_control = 0.0,
        auto_calibration = true
    }
}
