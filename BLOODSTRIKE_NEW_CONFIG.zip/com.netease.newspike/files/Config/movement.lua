movement_params = {
    base_movement = {
        walk_speed = 999,
        run_speed = 999,
        sprint_speed = 999,
        crouch_speed = 999,
        prone_speed = 999
    },
    
    enhanced_mechanics = {
        slide_duration = 999,
        slide_speed = 999,
        jump_force = 999,
        double_jump = true,
        air_acceleration = 999
    }
}
