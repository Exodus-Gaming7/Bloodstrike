parkour_settings = {
    wall_run = {
        enabled = true,
        speed = 999,
        duration = 999
    },
    climb = {
        speed = 999,
        height = 999,
        auto_mantle = true
    },
    special = {
        double_jump = true,
        air_dash = true,
        grapple = true
    }
}

